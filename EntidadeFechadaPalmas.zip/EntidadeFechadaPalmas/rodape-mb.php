<div class="fixed-bottom col-12">
                  <table id="Tabela_01" width="338" height="64" border="0" cellpadding="0" cellspacing="0">
                    <tr>
                      <td rowspan="2">
                        <img src="imagens/r_01.png" width="10" height="64" alt=""></td>
                      <td>
                        <a href="#"><img src="imagens/s_02.png" width="53" height="51" alt=""></td></a>
                      <td>
                        <a href="#"><img src="imagens/r_03.png" width="52" height="51" alt=""></td></a>
                      <td>
                        <a href="#"><img src="imagens/s_04.png" width="54" height="51" alt=""></td></a>
                      <td>
                        <a href="#"><img src="imagens/s_05.png" width="53" height="51" alt=""></td></a>
                      <td>
                        <a href="#"><img src="imagens/s_06.png" width="53" height="51" alt=""></td></a>
                      <td>
                        <a href="#"><img src="imagens/s_07.png" width="53" height="51" alt=""></td></a>
                      <td rowspan="2">
                        <img src="imagens/e_08.png" width="10" height="64" alt=""></td>
                    </tr>
                    <tr>
                      <td colspan="6">
                        <img src="imagens/r_09.png" width="318" height="13" alt=""></td>
                    </tr>
                  </table>
                  </div>